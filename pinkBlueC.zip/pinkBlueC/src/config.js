var clientIP = "http://localhost:63342";
var serverIP = "http://localhost:5000";

function getClientIP() {
    return clientIP;
}


function getServerIP() {
    return serverIP;
}
