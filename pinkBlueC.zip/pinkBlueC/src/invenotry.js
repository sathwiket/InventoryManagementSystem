var clientIP = getClientIP();
var serverIP = getServerIP();
window.onload = function () {
    var userInfo = localStorage.getItem("userInfo");
    if (userInfo === undefined || userInfo === null) {
        window.location.href = clientIP + '/pinkBlueC/html/login.html';
    } else {
        userInfo = JSON.parse(userInfo);
        var approveButton = document.getElementById("approvalButton");
        var displayName = document.getElementById("displayName");
        var roles = userInfo.roles;
        var storeManager = false;
        for (var i = 0; i < roles.length; i++) {
            var role = roles[i];
            if (role.name == "Store Manager") {
                storeManager = true;
                break;
            }
        }
        if (!storeManager) {
            approveButton.style.display = 'none';
        }
        displayName.innerHTML = userInfo.name;
    }
};
var modal;
var products = [];

function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    if (tabName === 'viewInventory') {
        viewInventory();
    } else if (tabName === 'approveInventory') {
        approveInventory();
    }
    evt.currentTarget.className += " active";
}


function createInventory() {
    startLoader();
    var productName = document.getElementById("pName").value;
    var vendor = document.getElementById("vendor").value;
    var mrp = document.getElementById("mrp").value;
    var batchNum = document.getElementById("batchNum").value;
    var quantity = document.getElementById("quantity").value;
    var batchDate = document.getElementById("batchDate").value;
    var res = validate(productName, mrp, batchNum, batchDate, quantity, vendor);
    var user_obj = localStorage.getItem("userInfo")
    user_obj = JSON.parse(user_obj)
    if (!res) {
        stopLoader();
        return;
    }
    var request = new XMLHttpRequest();
    var authToken = getAuthHeaderOrRedirectLogin();
    request.open('POST', serverIP + "/product", true);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Authorization", authToken);
    var requestBody = {
        user_id: user_obj.id,
        product_details:
            {
                product_name: productName,
                vendor_name: vendor,
                mrp: mrp,
                batch_num: batchNum,
                quantity: quantity,
                batch_date: batchDate
            }
    };
    var requestBodyStr = JSON.stringify(requestBody);
    console.log(requestBodyStr);
    request.onreadystatechange = function () {
        if (this.readyState == 4) {
            stopLoader();
        }
        if (this.readyState == 4 && this.status == 200) {
            window.alert("Successfully Created");
            clearFields();
        } else if (this.readyState == 4 && this.status == 401) {
            window.location.href = clientIP + '/pinkBlueC/html/login.html';
        } else if (this.readyState == 4) {
            window.alert(this.responseText);
        }
    }
    request.send(requestBodyStr);
}

function getProductById(id) {
    startLoader();
    var request = new XMLHttpRequest();
    var response;
    var product;
    request.open('GET', serverIP + "/product/" + id + "", true);
    request.onreadystatechange = function () {
        if (this.readyState == 4) {
            stopLoader();
            response = JSON.parse(this.responseText);
            product = response;
            return product;
        }
    };
    response.send();
}

function displayProduct(data) {
    var product;
    for (var i = 0; i < products.length; i++) {
        each = products[i];
        console.log(each);
        if (each.product_id == parseInt(data)) {
            product = each;
            break;
        }
    }
    console.log(product);
    document.getElementById("productId1").value = product.product_id;
    document.getElementById("pName1").value = product.product_name;
    document.getElementById("vendor1").value = product.vendor_name;
    document.getElementById("mrp1").value = product.mrp;
    document.getElementById("batchNum1").value = product.batch_num;
    document.getElementById("quantity1").value = product.quantity;
    console.log(product.batch_date);
    document.getElementById("batchDate1").value = product.batch_date;
    modal = document.getElementById("myModal");
    modal.style.display = "block";
}


function viewInventory() {
    products = [];
    startLoader();
    var tbl = document.getElementById('viewTable'), // table reference
        lastRow = tbl.rows.length - 1;
    for (var i = lastRow; i > 0; i--) {
        tbl.deleteRow(i);
    }
    var response;
    var authToken = getAuthHeaderOrRedirectLogin();
    var request = new XMLHttpRequest();
    request.open('GET', serverIP + "/products", true);
    request.setRequestHeader("Authorization", authToken);
    request.onreadystatechange = function () {
        if (this.readyState == 4) {
            stopLoader();
        }
        if (this.readyState == 4 && this.status == 200) {
            response = JSON.parse(this.responseText);
            products = response;
            /*products = [
                {
                    status: "active",
                    created_datetime: "2017-11-18",
                    product_id: 1,
                    batch_num: "1234807ABCD",
                    batch_date: "2017-10-20",
                    vendor_name: "PinkBlue",
                    mrp: 100.5,
                    product_name: "Stethescope",
                    quantity: 100
                }, {
                    status: "active",
                    created_datetime: "2017-11-18",
                    product_id: 2,
                    batch_num: "1234807ABCD",
                    batch_date: "2017-11-23",
                    vendor_name: "PinkBlue",
                    mrp: 100.5,
                    product_name: "StethescopeX",
                    quantity: 100
                }
            ];*/
            var table = document.getElementById("viewTable");
            for (var i = 0; i < products.length; i++) {
                var each = products[i];
                var row = table.insertRow(i + 1);
                row.setAttribute("data", each.product_id);
                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                var cell3 = row.insertCell(2);
                var cell4 = row.insertCell(3);
                var cell5 = row.insertCell(4);
                var cell6 = row.insertCell(5);
                var cell7 = row.insertCell(6);
                var cell8 = row.insertCell(7);
                var cell9 = row.insertCell(8);
                cell1.innerHTML = each.product_id;
                cell2.innerHTML = each.product_name;
                cell3.innerHTML = each.quantity;
                cell4.innerHTML = each.mrp;
                cell5.innerHTML = each.vendor_name;
                cell6.innerHTML = each.status;
                cell7.innerHTML = each.created_datetime;
                cell8.innerHTML = each.batch_date;
                cell9.innerHTML = each.batch_num;
                console.log(row.getAttribute("data"));
                row.addEventListener('click', function () {
                    displayProduct(this.getAttribute("data"));
                });
            }
        } else if (this.readyState == 4 && this.status == 401) {
            window.location.href = clientIP + '/pinkBlueC/html/login.html';
        } else if (this.readyState == 4) {
            window.alert(this.responseText);
        }
    };
    request.send();
}

function approveInventory() {
    startLoader();
    var tbl = document.getElementById('approveTable'), // table reference
        lastRow = tbl.rows.length - 1;
    for (var i = lastRow; i > 0; i--) {
        tbl.deleteRow(i);
    }
    var approvalFilter = document.getElementById("approvalFilter");
    var filter = approvalFilter.value;
    console.log(filter);
    var response;
    var status;
    if (filter == "pending") {
        status = 1;
    } else {
        status = 2;
        approvalFilter.style.display = 'none';
    }
    var query_param = "?status=" + filter;
    var authToken = getAuthHeaderOrRedirectLogin();
    var request = new XMLHttpRequest();
    request.open('GET', serverIP + "/product/requests" + query_param, true);
    request.setRequestHeader("Authorization", authToken);
    request.onreadystatechange = function () {
        if (this.readyState == 4) {
            stopLoader();
        }
        if (this.readyState == 4 && this.status == 200) {
            response = JSON.parse(this.responseText);
            var records = response;
            /*var records = [{
                user_name: "Kamal",
                request_type: "update_product",
                request_id: 121,
                product_detail: {
                    product_id: 1,
                    product_name: "Stethescope",
                    mrp: 100.876,
                    quantity: 15,
                    batch_num: "1234807ABCD",
                    batch_date: "2017-11-18",
                    vendor_name: "PinkBlue"
                }
            }];*/
            var table = document.getElementById("approveTable");
            for (var i = 0; i < records.length; i++) {
                var each = records[i];
                product = each.product_details;
                var row = table.insertRow(i + 1);
                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                var cell3 = row.insertCell(2);
                var cell4 = row.insertCell(3);
                var cell5 = row.insertCell(4);
                var cell6 = row.insertCell(5);
                var cell7 = row.insertCell(6);
                var cell8 = row.insertCell(7);
                cell1.innerHTML = product.product_id;
                cell2.innerHTML = product.product_name;
                cell3.innerHTML = product.quantity;
                cell4.innerHTML = product.vendor_name;
                cell5.innerHTML = product.mrp;
                cell6.innerHTML = each.request_type;
                cell7.innerHTML = each.user_name;
                var select = document.createElement('select');
                select.setAttribute("requestId", each.request_id);
                select.addEventListener('change', function () {
                    if (this.value.trim() !== "select") {
                        var id = this.getAttribute("requestId");
                        var status;
                        if (this.value.trim() == "approve") {
                            status = "approved";
                        } else if (this.value.trim() == "reject") {
                            status = "rejected";
                        }
                        updateApprovalRequest(id, status);
                    }
                });
                var option;
                var inputdata = "select || approve || reject ";

                inputdata.split('||').forEach(function (item) {

                    option = document.createElement('option');

                    option.value = option.textContent = item;

                    select.appendChild(option);
                });
                cell8.appendChild(select);
            }
            //alert("something went wrong");
        } else if (this.readyState == 4 && this.status == 401) {
            window.location.href = clientIP + '/pinkBlueC/html/login.html';
        } else if (this.readyState == 4) {
            window.alert(this.responseText);
        }
    };
    request.send();
};

function close_wind() {
    modal.style.display = "none";
};

function updateProduct() {
    startLoader();
    var productId = document.getElementById("productId1").value;
    var productName = document.getElementById("pName1").value;
    var vendor = document.getElementById("vendor1").value;
    var mrp = document.getElementById("mrp1").value;
    var batchNum = document.getElementById("batchNum1").value;
    var quantity = document.getElementById("quantity1").value;
    var batchDate = document.getElementById("batchDate1").value;
    var res = validate(productName, mrp, batchNum, batchDate, quantity, vendor);
    if (!res) {
        stopLoader();
        return;
    }
    var authToken = getAuthHeaderOrRedirectLogin();
    var request = new XMLHttpRequest();
    request.open('PUT', serverIP + "/product/" + productId + "", true);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Authorization", authToken);
    var requestBody = {
        product_name: productName,
        vendor_name: vendor,
        mrp: mrp,
        batch_num: batchNum,
        quantity: quantity,
        batch_date: batchDate
    };
    console.log(requestBody);
    var requestBodyStr = JSON.stringify(requestBody);
    request.onreadystatechange = function () {
        if (this.readyState == 4) {
            stopLoader();
        }
        if (this.readyState == 4 && this.status == 200) {
            alert("Successfully Updated");
            modal.style.display = "none";
            viewInventory();
        } else if (this.readyState == 4 && this.status == 401) {
            window.location.href = clientIP + '/pinkBlueC/html/login.html';
        } else if (this.readyState == 4) {
            window.alert(this.responseText);
        }
    };
    request.send(requestBodyStr);
}

function deleteProduct() {
    startLoader();
    var authToken = getAuthHeaderOrRedirectLogin();
    var productId = document.getElementById("productId1").value;
    var request = new XMLHttpRequest();
    request.open('DELETE', serverIP + "/product/" + productId + "", true);
    request.setRequestHeader("Authorization", authToken);
    request.onreadystatechange = function () {
        if (this.readyState == 4) {
            stopLoader();
        }
        if (this.readyState == 4 && this.status == 200) {
            alert("Successfully Deleted");
            modal.style.display = "none";
            viewInventory();
        } else if (this.readyState == 4 && this.status == 401) {
            window.location.href = clientIP + '/pinkBlueC/html/login.html';
        } else if (this.readyState == 4) {
            window.alert(this.responseText);
        }
    };
    request.send();
}

function updateApprovalRequest(id, status) {
    startLoader();
    var authToken = getAuthHeaderOrRedirectLogin();
    var request = new XMLHttpRequest();
    request.open('PUT', serverIP + "/product/request/" + id + "", true);
    request.setRequestHeader("Content-type", "application/json");
    request.setRequestHeader("Authorization", authToken);
    var requestPayload = {
        status: status
    };
    var requestBodyStr = JSON.stringify(requestPayload);
    console.log(requestPayload);
    request.onreadystatechange = function () {
        if (this.readyState == 4) {
            stopLoader();
        }
        if (this.readyState == 4 && this.status == 200) {
            alert("Successfully Updated");
            approveInventory();
        } else if (this.readyState == 4 && this.status == 401) {
            window.location.href = clientIP + '/pinkBlueC/html/login.html';
        } else if (this.readyState == 4) {
            window.alert(this.responseText);
        }
    };
    request.send(requestBodyStr);
}

function startLoader() {
    var loader = document.getElementById("loader");
    loader.style.display = 'block';
}

function stopLoader() {
    var loader = document.getElementById("loader");
    loader.style.display = 'none';
}

function validate(productName, mrp, batchNumber, batchDate, quantity, vendorName) {
    if (isEmpty(productName)) {
        alert("ProductName cannot be empty");
        //createErrorMessage.innerHTML = "ProductName cannot be empty";
        return false;
    }
    if (isEmpty(mrp)) {
        alert("MRP cannot be empty");
        return false;
    }
    if (isEmpty(batchNumber)) {
        alert("BatchNumber cannot be empty");
        return false;
    }
    if (isEmpty(batchDate)) {
        alert("BatchDate cannot be empty");
        return false;
    }
    if (isEmpty(quantity)) {
        alert("Quantity cannot be empty");
        return false;
    } else if (quantity < 0) {
        alert("Quantity cannot be less than zero");
        return false;
    }
    if (isEmpty(vendorName)) {
        alert("VendorName cannot be empty");
        return false;
    }
    return true;
}

function isEmpty(field) {
    if (field === undefined || field == "") {
        return true;
    }
    return false;
}

function getAuthHeaderOrRedirectLogin() {
    var userInfo = localStorage.getItem("userInfo");
    var authToken;
    var redirect = false;
    if (userInfo === undefined || userInfo === null) {
        redirect = true;
    } else {
        userInfo = JSON.parse(userInfo);
        if (userInfo.auth_token == undefined || userInfo.auth_token == "") {
            redirect = true;
        } else {
            return userInfo.auth_token;
        }
    }
    if (redirect) {
        window.location.href = clientIP + '/pinkBlueC/html/login.html';
    }
}

function clearFields() {
    document.getElementById("pName").value = "";
    document.getElementById("vendor").value = "";
    document.getElementById("mrp").value = "";
    document.getElementById("batchNum").value = "";
    document.getElementById("quantity").value = "";
    document.getElementById("batchDate").value = "";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
};
