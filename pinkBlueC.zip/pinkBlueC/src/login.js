function userLogin() {
    var clientIP = getClientIP();
    var serverIP = getServerIP();
    var loader = document.getElementById("loader");
    loader.style.display = 'block';
    var username = document.getElementById("userId").value;
    var password = document.getElementById("password").value;
    var res = validate(username, password);
    if (!res) {
        loader.style.display = 'none';
        return;
    }
    var request = new XMLHttpRequest();
    request.open('POST', serverIP + "/login", true);
    request.setRequestHeader("Access-Control-Allow-Origin", "*");
    request.setRequestHeader("Content-type", "application/json");
    var requestBody = {
        user_name: username,
        password: password
    };
    var requestBodyStr = JSON.stringify(requestBody);
    request.onreadystatechange = function () {
        /*var response = {
            id: 1221,
            name: "Krishna",
            roles: [
                {
                    id: 12,
                    name: "STORE_MANAGER"
                },
                {
                    id: 13,
                    name: "SALE_MANAGER"
                }
            ],
            authToken: "Basic cHVsbGE6MTIzNDU2"
        };*/
        if (this.readyState == 4) {
            console.log(this.responseText);
            loader.style.display = 'none';
        }
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("loginMessage").innerHTML = "successful";
            var response = JSON.parse(this.responseText);
            localStorage.setItem("userInfo", JSON.stringify(response));
            window.location.href = clientIP + '/pinkBlueC/html/home.html';
        } else if (this.readyState == 4 && this.status == 401) {
            document.getElementById("loginMessage").innerHTML = "invalid credentials";
        } else if (this.readyState == 4) {
            document.getElementById("loginMessage").innerHTML = this.responseText;
        }
    };
    request.send(requestBodyStr);
}

function validate(userName, password) {
    if (userName === undefined || userName == "" || userName == null) {
        document.getElementById("loginMessage").innerHTML = "UserName cannot be empty";
        return false;
    }
    if (password === undefined || password == "" || password == null) {
        document.getElementById("loginMessage").innerHTML = "Password cannot be empty";
        return false;
    }
    return true;
}

window.onload = function () {
    var clientIP = getClientIP();
    var serverIP = getServerIP();
    var userInfo = localStorage.getItem("userInfo");
    if (userInfo != undefined && userInfo != "") {
        window.location.href = clientIP + '/pinkBlueC/html/home.html';
    }
};
