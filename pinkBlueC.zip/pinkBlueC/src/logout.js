function logout() {
    var clientIP = getClientIP();
    localStorage.removeItem("userInfo");
    window.location.href = clientIP + '/pinkBlueC/html/login.html';
}