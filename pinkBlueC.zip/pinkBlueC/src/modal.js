// Get the modal


// When the user clicks on <span> (x), close the modal
